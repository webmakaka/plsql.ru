DELETE FROM departments
WHERE  department_name = 'Public Relations';

DROP TABLE sales_reps;


DROP TABLE copy_emp;



DROP TABLE test;


UPDATE  employees
SET   department_id = 110
WHERE employee_id = 206;

UPDATE   employees
SET   job_id  = 'IT_PROG'
WHERE    employee_id    =  103;

UPDATE   employees
SET   salary=9000
WHERE employee_id = 103;





