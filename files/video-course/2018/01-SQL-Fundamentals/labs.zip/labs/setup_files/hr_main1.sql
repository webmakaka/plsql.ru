REM   Script:   hr_main1.sql
REM   Purpose:  To create users and initialise scripts that create schema objects.
REM  Created: By Apoorva Srinivas on 15-June-17 	
  
--Please modify the path based on the location of the scripts.  

@@hr_cre.sql
@@hr_popul.sql
@@hr_idx.sql
@@hr_comnt.sql




