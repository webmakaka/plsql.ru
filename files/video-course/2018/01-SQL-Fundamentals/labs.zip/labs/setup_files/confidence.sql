REM  Script:  confidence.sql
REM  Purpose: To check the desired number of rows
REM  Created: By Apoorva Srinivas on 15-June-17 
REM          
select count(*) from tab;
select count(*) from employees;
select count(*) from countries;
select count(*) from regions;
select count(*) from locations;
select count(*) from departments;
select count(*) from jobs;
select count(*) from job_history;
